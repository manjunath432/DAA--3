def dfs(graph, start, visited):
    visited.add(start)
    print(start, end=" ")

    for neighbor in graph[start]:
        if neighbor not in visited:
            dfs(graph, neighbor, visited)


# Number of vertices
n = int(input("Enter number of vertices: "))

graph = {}

# Enter vertices
for i in range(n):
    vertex = input(f"Enter vertex {i + 1}: ")
    graph[vertex] = []

# Number of edges
e = int(input("Enter number of edges: "))

# Enter edges
for i in range(e):
    u = input(f"Enter starting vertex for edge {i + 1}: ")
    v = input(f"Enter ending vertex for edge {i + 1}: ")

    graph[u].append(v)
    graph[v].append(u)   # Remove this line for directed graph

# Starting vertex
start = input("Enter starting vertex for DFS: ")

visited = set()

print("\nDFS Traversal:", end=" ")
dfs(graph, start, visited)