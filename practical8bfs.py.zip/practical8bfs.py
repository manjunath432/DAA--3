from collections import deque

# BFS Function
def bfs(graph, start):
    visited = set()
    queue = deque()

    visited.add(start)
    queue.append(start)

    print("BFS Traversal:", end=" ")

    while queue:
        vertex = queue.popleft()
        print(vertex, end=" ")

        for neighbor in graph[vertex]:
            if neighbor not in visited:
                visited.add(neighbor)
                queue.append(neighbor)


# User Input
n = int(input("Enter number of vertices: "))

graph = {}

# Create graph
for i in range(n):
    vertex = input(f"Enter vertex {i + 1}: ")
    graph[vertex] = []

# Add edges
e = int(input("Enter number of edges: "))

for i in range(e):
    u = input(f"Enter starting vertex for edge {i + 1}: ")
    v = input(f"Enter ending vertex for edge {i + 1}: ")

    graph[u].append(v)
    graph[v].append(u)   # Remove this line for a directed graph

# Starting vertex
start = input("Enter starting vertex for BFS: ")

# Perform BFS
bfs(graph, start)